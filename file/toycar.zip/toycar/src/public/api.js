let host = '/api';
export default {
    project: host + '/toycar/project',
    projectlist: host + '/toycar/projectlist',
    getproject: host + '/toycar/getproject',
}